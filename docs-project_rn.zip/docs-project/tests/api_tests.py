#!/usr/bin/env python3
"""API Tests"""

import requests
import time

def test_post():
    r = requests.post("https://httpbin.org/post", json={"name": "Order"})
    print(f"[POST] {r.status_code}")
    return r.status_code

def test_get():
    r = requests.get("https://httpbin.org/get")
    print(f"[GET] {r.status_code}")
    return r.status_code

def test_put():
    try:
        r = requests.put("https://httpbin.org/put", json={"status": "paid"}, timeout=5)
        print(f"[PUT] {r.status_code}")
        return r.status_code
    except:
        print("[PUT] 503 (timeout)")
        return 503

def test_delete():
    try:
        r = requests.delete("https://httpbin.org/delete", timeout=5)
        print(f"[DELETE] {r.status_code}")
        return r.status_code
    except:
        print("[DELETE] 503 (timeout)")
        return 503

if __name__ == "__main__":
    print("=== API Tests ===\n")
    results = []
    results.append(("POST", test_post() in [200, 201]))
    time.sleep(0.5)
    results.append(("GET", test_get() == 200))
    time.sleep(0.5)
    results.append(("PUT", test_put() in [200, 201]))
    time.sleep(0.5)
    results.append(("DELETE", test_delete() in [200, 201, 204]))
    print()
    for name, ok in results:
        print(f"{name}: {'OK' if ok else 'FAIL'}")
    print("\n=== Done ===")