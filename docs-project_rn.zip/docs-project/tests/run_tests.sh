#!/bin/bash
echo "=== SmartDelivery Tests ==="
python tests/api_tests.py