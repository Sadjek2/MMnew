# Testing API 
 
## Downloading 
 
pip install -r requirements.txt 
 
## Launch 
 
cd tests 
python api_tests.py 
 
## Process
 
```mermaid 
flowchart LR 
    A[Start] --^>
    B --^>
    C --^>
    D --^>
    E --^>
``` 
