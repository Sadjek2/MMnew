# SmartDelivery Architecture

## System review

Система SmartDelivery построена на микросервисной архитектуре.

## System components
```mermaid
graph LR
    Client[Клиент (APP/Web)] -- REST API --> Gateway
    Gateway -- Proxy --> Auth[Сервис Auth]
    Gateway -- Proxy --> Order[Сервис Заказов]
    Order -- SQL --> DB[(PostgreSQL)]
    Order -- Async --> Queue[RabbitMQ]
    Queue -- Event --> Courier[Сервис Курьер]

## Жизненный цикл заказа
```mermaid
sequenceDiagram
    participant Клиент
    participant API
    participant БД
    participant ПлатежныйШлюз
    participant Курьер

    Клиент->>API: POST /api/orders (создание)
    API->>БД: Сохранение
    БД-->>API: OK
    API-->>Клиент: 201 Created

    Клиент->>API: Оплата
    API->>ПлатежныйШлюз: Запрос оплаты
    ПлатежныйШлюз-->>API: Успех
    API->>БД: Статус "paid"

    API->>Курьер: Назначение
    Курьер->>API: Принял
    API->>БД: Статус "in_transit"

    Курьер->>API: Доставлен
    API->>БД: Статус "delivered"
    API-->>Клиент: Уведомление

## Процесс обработки заказа
```mermaid
    flowchart TD
    A[Начало] --> B{Валидация}
    B -->|Ошибка| C[Возврат ошибки]
    B -->|OK| D[Сохранение в БД]
    D --> E[Резервирование]
    E --> F{Товар доступен?}
    F -->|Нет| G[Отмена]
    F -->|Да| H[Ожидание оплаты]
    H --> I{Оплата?}
    I -->|Нет| J[Таймаут]
    I -->|Да| K[Курьер]
    K --> L[Доставка]
    L --> M{Успех?}
    M -->|Нет| N[Возврат]
    M -->|Да| O[Завершено]