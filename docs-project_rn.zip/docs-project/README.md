# SmartDelivery Documentation

Документация API сервиса SmartDelivery.

## Установка

```bash
pip install -r requirements.txt